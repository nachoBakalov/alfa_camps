export function AdminDashboardPage() {
  return (
    <main className="min-h-screen p-8">
      <div className="mx-auto max-w-2xl rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <h1 className="text-2xl font-semibold text-slate-900">Admin Dashboard</h1>
        <p className="mt-2 text-slate-600">Placeholder admin screen.</p>
      </div>
    </main>
  );
}
