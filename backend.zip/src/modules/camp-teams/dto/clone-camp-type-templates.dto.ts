export class CloneCampTypeTemplatesDto {}
